package com.algorand.sdkutils.generators;

public class DiffResult {

    public String fullOutput;
    public String justDiff;
    public boolean pass;
    public boolean filtered;
}
