package com.algorand.algosdk.kmd.client.api;

import com.algorand.algosdk.kmd.client.ApiClient;

public class KmdApi extends DefaultApi {

    public KmdApi() {
        super();
    }

    public KmdApi(ApiClient apiClient) {
        super(apiClient);
    }
}
